<?php 
require 'header.php';
new Header('Startpage');
?>

<div class="container">
	<?php require 'sidebar.php';?>
	<!-- content -->
	<section id="content">


		<div id="banner"></div>


		<div class="inside">
			<hr />
			<p></p>
			<h2>
				Welcome to <span class="txt1">StudyStuff</span>.
			</h2>

			<p class="txt1">
				<span>Here you can share material of course with your fellow
					students, rate others uploaded course and materials. It will be a
					huge help for your study preparation.</span>
			</p>
			<h3>Find your university!</h3>
			<h3>Find your course!</h3>
			<h3>Find new material!</h3>
			<h3>Be succesfull!</h3>


		</div>
	</section>
</div>
</div>

<?php 
require 'footer.php';
?>

<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
