
<?php 
require 'header.php';
new Header('Download');
?>

<div class="container">
	<?php require 'sidebar.php';?>
	<!-- content -->
	<section id="content"></section>
</div>
</div>

<?php 
require 'footer.php';
?>

<script type="text/javascript"> Cufon.now(); </script>
</body>
</html>
