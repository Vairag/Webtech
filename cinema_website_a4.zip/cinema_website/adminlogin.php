<?php error_reporting (E_ALL ^ E_NOTICE); ?>
<html>
<head>
    
	<script type="text/javascript">
	function cancelForm()
	{  
		document.forms["loginform"]["usrname"].value="";
		document.forms["loginform"]["pwd"].value="";
		
	}
    </script>	
</head>
<body>
<div style="margin-left:300px;">

<h1>BoX Office Employee Panel</h1>
<div id="area">
<form name="loginform" action="checklogin.php" method="post" enctype="multipart/form-data" >


	Employee Id :&nbsp;&nbsp;<input name="usrname" id="usrname" type="text" required="required"/><br/><br/>
    Password &nbsp;&nbsp;&nbsp;&nbsp;:&nbsp;&nbsp;<input name="pwd" id="pwd" type="password" required="required"/><br/><br/>
	<input type="submit" id="buttonsubmit" value="LOGIN"/>
	<input type="button" id="buttoncancel" value="Back to HOME Panel" ONCLICK="window.location.href='index.htm'"/>
	
	
	<div id="fillerror" >
	
		   <?php
		        
		       if($_GET['err']=="failed")
			    {
			     echo "Username or Password is not correct!";
			    }
				if($_GET['err']=="success")
				{
			     echo "Password is sent to your email!";
				}
			
		   ?>
    </div>  
</form>
<h3>Please login with<br> Employee Id : employee1 & Password : boxoffice 
    
</h3>

<a id="newuser" href="">Don't have account! Register Now ? (Will be implemented Later !)</a>
<br/>
<a  id="frgetpwd"  href="">Forgot your Password ? (Will be implemented Later !)</a><br/>
</a><br/><br/>
</div>
</div>
</body>
</html>
