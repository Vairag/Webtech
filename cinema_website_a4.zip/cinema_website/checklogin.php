<?php
 // Database connection
include("config.php");		 
		   // Send email on Forgot Password...will be implementated later !
		   if($_GET['err']=="forgot")
		   {    
		       
		       /*
			   if(config()) 
			   {
			     $result=mysql_query("SELECT * FROM admin");
				while($row = mysql_fetch_array($result))
				{
				   $message = "Dear Admin, 
				   Below is your Admin credentials. 
				   Username : ".$row['adminname']." 
				   Password : ".$row['adminpwd']."\nRegards\nYour CoupenList Team";
				}
			    
				$to2 = "jty@nakialtech.ca";
				//$to3 = "gunjan.kalariya@solution-hawk.com";
				$subject = "Your Password at CoupenList !";
				
				$from = "jty@nakialtech.ca";
				$headers = "From:" . $from;
				
				mail($to2,$subject,$message,$headers);
				//mail($to3,$subject,$message,$headers);
				
		        header("Location:index.php?err=success");
				
			 }*/
		   }
          else if(config())
		  { 	  
		    //check for correct Employee Id & PWD match
			$result=mysql_query("SELECT * FROM `box_office_employees` WHERE `box_office_employees_id`='".$_POST['usrname']."' and `box_office_employees_pwd`='".$_POST['pwd']."'");
			
			$row = mysql_num_rows($result);
			if($row)
			{
			  // Start Session & add box_office_employees_id to Session 
		      session_start();
			  $_SESSION['box_office_employees_id']=$_POST['usrname'];
			 
			header("Location:main.php");
			}
			else
			{  
			  header("Location:adminlogin.php?err=failed");
			
			}
           }
		   
?>