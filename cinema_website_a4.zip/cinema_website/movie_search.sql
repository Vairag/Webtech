-- phpMyAdmin SQL Dump
-- version 2.11.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 08, 2012 at 01:05 AM
-- Server version: 5.0.45
-- PHP Version: 5.2.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `movie_search`
--

-- --------------------------------------------------------

--
-- Table structure for table `box_office_employees`
--

CREATE TABLE `box_office_employees` (
  `box_office_employees_id` varchar(30) collate latin1_general_ci NOT NULL,
  `box_office_employees_pwd` varchar(30) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`box_office_employees_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `box_office_employees`
--

INSERT INTO `box_office_employees` (`box_office_employees_id`, `box_office_employees_pwd`) VALUES
('employee1', 'boxoffice'),
('raja', 'raja');

-- --------------------------------------------------------

--
-- Table structure for table `cinemas`
--

CREATE TABLE `cinemas` (
  `cinema_id` int(11) NOT NULL auto_increment,
  `cinema_name` varchar(20) collate latin1_general_ci NOT NULL,
  `cinema_address` varchar(100) collate latin1_general_ci NOT NULL,
  `cinema_website` varchar(60) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`cinema_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `cinemas`
--

INSERT INTO `cinemas` (`cinema_id`, `cinema_name`, `cinema_address`, `cinema_website`) VALUES
(1, 'Apollo Aachen', 'PontStrasse 141-149, Aachen', 'http://www.apollo-aachen.de'),
(2, 'Cineplex Aachen', 'Borngasse 30, 52064 Aachen', 'http://www.cineplex.de'),
(3, 'Eden Palast Aachen', 'Franzstrasse 45 52064 Aachen', 'http://www.cineplex.de/kino/tree/node2415/city1/');

-- --------------------------------------------------------

--
-- Table structure for table `movies`
--

CREATE TABLE `movies` (
  `movie_id` int(11) NOT NULL auto_increment,
  `movie_name` varchar(50) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`movie_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `movies`
--

INSERT INTO `movies` (`movie_id`, `movie_name`) VALUES
(1, 'Die Wand'),
(2, 'Liebe'),
(3, 'Sneak'),
(4, 'Angel''s Share'),
(5, 'Der Deutsche Freund'),
(6, 'Lore'),
(7, 'SkyFall');

-- --------------------------------------------------------

--
-- Table structure for table `movie_viewer`
--

CREATE TABLE `movie_viewer` (
  `movie_viewer_id` int(11) NOT NULL auto_increment,
  `movie_viewer_name` varchar(30) collate latin1_general_ci NOT NULL,
  `movie_viewer_email` varchar(50) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`movie_viewer_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=511 ;

--
-- Dumping data for table `movie_viewer`
--

INSERT INTO `movie_viewer` (`movie_viewer_id`, `movie_viewer_name`, `movie_viewer_email`) VALUES
(101, 'Tobias', 'tobias@gmail.com'),
(201, 'Vairag', 'vairag@gmail.com'),
(301, 'Arkadi', 'arkadi@gmail.com'),
(401, 'Alex', 'alex@gmail.com'),
(501, 'mohamad', 'mohamad@gmail.com'),
(502, 'raja', 'raja@gmail.com'),
(503, 'ankit', 'ankit@gmail.com'),
(504, 'mmmaa', 'maa@gmail.com'),
(505, 'hi', 'hello@gmail.com'),
(506, 'kela', 'kela@gmail.com'),
(507, 'hi', 'kela@gmail.com'),
(508, 'paresh', 'paresh@gmail.com'),
(509, 'km6o', 'raja@gmail.com'),
(510, 'vairag', 'vairag@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `reservation`
--

CREATE TABLE `reservation` (
  `reservation_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(30) collate latin1_general_ci NOT NULL,
  `user_email` varchar(50) collate latin1_general_ci NOT NULL,
  `cinema_name` varchar(100) collate latin1_general_ci NOT NULL,
  `movie_name` varchar(60) collate latin1_general_ci NOT NULL,
  `seats` varchar(100) collate latin1_general_ci NOT NULL,
  PRIMARY KEY  (`reservation_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `reservation`
--

INSERT INTO `reservation` (`reservation_id`, `user_name`, `user_email`, `cinema_name`, `movie_name`, `seats`) VALUES
(1, 'vairag', 'vairag@gmail.com', 'Capitol', 'Hotel Trasilvanien', '56,57'),
(2, 'ankit', 'ankit@gmail.com', 'Capitol', 'Skyfall', '9,29,39'),
(3, 'Parag', 'Parag@gmail.com', 'Apollo Kino', 'Agent Ranjid rettet die Welt', '20,0,3,23,33,73,63,64,65,66,15,14,4'),
(4, 'mohamad', 'mohamad@gmail.com', 'Capitol', 'Agent Ranjid rettet die Welt', '20,41,42,,43'),
(5, 'ramani', 'ramani@gmail.com', 'Smoky Sex + Gay Discount & Kino', 'Hotel Trasilvanien', '0,3,4,5,6');

-- --------------------------------------------------------

--
-- Table structure for table `reservation_old`
--

CREATE TABLE `reservation_old` (
  `reservation_id` int(11) NOT NULL auto_increment,
  `movie_viewer_id` int(11) NOT NULL,
  `show_id` int(11) NOT NULL,
  `seat` int(11) NOT NULL,
  PRIMARY KEY  (`reservation_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=6 ;

--
-- Dumping data for table `reservation_old`
--

INSERT INTO `reservation_old` (`reservation_id`, `movie_viewer_id`, `show_id`, `seat`) VALUES
(1, 101, 1, 25),
(2, 201, 5, 34),
(3, 301, 7, 12),
(4, 401, 10, 50),
(5, 501, 12, 43);

-- --------------------------------------------------------

--
-- Table structure for table `shows`
--

CREATE TABLE `shows` (
  `show_id` int(11) NOT NULL auto_increment,
  `cinema_id` int(11) NOT NULL,
  `movie_id` int(11) NOT NULL,
  `show_time` time NOT NULL,
  PRIMARY KEY  (`show_id`),
  KEY `fk_movie` (`movie_id`),
  KEY `fk_cinema` (`cinema_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=13 ;

--
-- Dumping data for table `shows`
--

INSERT INTO `shows` (`show_id`, `cinema_id`, `movie_id`, `show_time`) VALUES
(1, 1, 1, '09:00:00'),
(2, 1, 2, '12:00:00'),
(3, 1, 3, '15:00:00'),
(4, 1, 4, '18:00:00'),
(5, 2, 3, '09:00:00'),
(6, 2, 4, '12:00:00'),
(7, 2, 5, '15:00:00'),
(8, 2, 6, '18:00:00'),
(9, 3, 2, '09:00:00'),
(10, 3, 5, '12:00:00'),
(11, 3, 6, '15:00:00'),
(12, 3, 7, '18:00:00');
